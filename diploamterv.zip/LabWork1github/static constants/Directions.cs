﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork1github.static_constants
{
    public static class Directions
    {
        public const string FORWARD = "F";
        public const string RIGHT = "R";
        public const string BACKWARDS = "B";
        public const string LEFT = "L";
        public const string COLLISION = "collision";
        public const string AWAY = "away";
    }
}
