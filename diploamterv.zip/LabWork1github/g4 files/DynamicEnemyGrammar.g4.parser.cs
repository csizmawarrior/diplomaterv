﻿namespace LabWork1github
{
    partial class DynamicEnemyGrammarParser
    {
    }
}
