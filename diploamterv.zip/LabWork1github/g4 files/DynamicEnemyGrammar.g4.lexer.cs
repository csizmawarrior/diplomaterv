﻿namespace LabWork1github
{
    partial class DynamicEnemyGrammarLexer
    {
        private string enemyName = "";

    }
}
