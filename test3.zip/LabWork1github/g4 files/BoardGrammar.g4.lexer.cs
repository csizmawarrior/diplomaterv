﻿namespace LabWork1github
{
    partial class BoardGrammarLexer
    {
    }
}
