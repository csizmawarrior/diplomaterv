﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork1github.Visitors
{
    public enum TypeCreationStage
    {
        ParameterDeclare,
        CommandListing,
        EventCommandBlock,
        ConditionalCommandBlock
    }
}
